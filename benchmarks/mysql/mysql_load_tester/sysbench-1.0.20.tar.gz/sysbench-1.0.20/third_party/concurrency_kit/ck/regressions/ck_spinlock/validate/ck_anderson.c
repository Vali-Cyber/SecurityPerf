#include "../ck_anderson.h"
#include "validate.h"
